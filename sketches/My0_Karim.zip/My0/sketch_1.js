import { createEngine } from "../../shared/engine.js";
import { createSpringSettings, Spring } from "../../shared/spring.js";

const { renderer, input, math, run, finish } = createEngine();
const { ctx, canvas } = renderer;
run(update);

const spring = new Spring({
  position: 0,
});

const settings1 = createSpringSettings({
  frequency: 3.5,
  halfLife: 0.05,
});
const settings2 = createSpringSettings({
  frequency: 0.2,
  halfLife: 1.15,
});

let candyRadius = 30;




// Initial positions for the triangles
let leftTriangleY = 0;
let rightTriangleY = 0;

// Falling speed
const fallSpeed = 700;

// Falling state
let isFalling = false;

function update(dt) {
  // Start falling when mouse is clicked
  if (input.isPressed()) {
    spring.target = -0.1;
    spring.settings = settings2;
    candyRadius += 1;
    isFalling = true; // Enable falling when mouse is clicked
  } else {
    spring.target = 1;
    spring.settings = settings1;
  }

  // Update positions only if falling
  if (isFalling) {
    leftTriangleY += fallSpeed * dt;
    rightTriangleY += fallSpeed * dt;
  }

  spring.step(dt);

  const x = canvas.width / 2;
  const y = canvas.height / 2;
  const scale = Math.max(spring.position, 0);

  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Draw the candy with packaging
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(math.toRadian(-spring.velocity * 0.03));

  // Draw the left triangle
  ctx.fillStyle = "blue";
  ctx.beginPath();
  ctx.moveTo(-50, -30 + leftTriangleY);
  ctx.lineTo(-30, 0 + leftTriangleY);
  ctx.lineTo(-50, 30 + leftTriangleY);
  ctx.closePath();
  ctx.fill();

  // Draw the right triangle
  ctx.beginPath();
  ctx.moveTo(50, -30 + rightTriangleY);
  ctx.lineTo(30, 0 + rightTriangleY);
  ctx.lineTo(50, 30 + rightTriangleY);
  ctx.closePath();
  ctx.fill();

  // Draw the circle candy
  ctx.fillStyle = "red";
  ctx.beginPath();
  ctx.arc(0, 0, candyRadius, 0, Math.PI * 2);
  ctx.fill();

  if (candyRadius > 500) {
    ctx.translate(-canvas.width / 2, -canvas.height / 2);
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "white"
    ctx.textBaseline = "middle"
    ctx.font = `${canvas.height}px Helvetica Neue, Helvetica , bold`
    ctx.textAlign = "center"
    ctx.translate(x, y)
    ctx.fillText("0", 0, 0)
  }

  ctx.restore();

  // if (scale <= 0) {
  //   finish();
  // }
}
